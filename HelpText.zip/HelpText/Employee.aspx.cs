﻿using HelpText.BusinessLogicLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HelpText
{
    public partial class Employee : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            GetEmployeeDetails();
        }

        protected void BtnSubmit_Click(object sender, EventArgs e)
        {
            int count = 0;
            EmployeeBAL employeeBAL = new EmployeeBAL();
            string empName = txtEmpName.Text;
            string designation = ddlDesignation.SelectedItem.ToString();
            string location = txtLocation.Text;
            count = employeeBAL.InsertEmployeeDetails(empName,designation,location);
            if(count >0)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", "Employee Records Inserted successfully.");
                GetEmployeeDetails();
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", "Employee Records Insertion Failed.");
            }
        }

        private void GetEmployeeDetails()
        {
            EmployeeBAL employeeBAL = new EmployeeBAL();
            DataSet dataSet = new DataSet();
            dataSet = employeeBAL.GetEmployeeDetails();
            grdEmployee.DataSource = dataSet.Tables[0];
            grdEmployee.DataBind();
        }
    }
}