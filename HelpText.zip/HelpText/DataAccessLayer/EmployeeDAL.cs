﻿using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System;

namespace HelpText.DataAccessLayer
{
    public class EmployeeDAL
    {
        public int InsertEmployeeDetails(string empName, string designation, string location)
        {
            int count = 0;
            //string conString = ConfigurationManager.AppSettings["myConnectionString"].ToString();
            //SqlCommand cmd = new SqlCommand("INSERT INTO Employee (EmployeeName,Designation,Location,CreatedDate,ModifiedDate) VALUES('" + empName + "','" + designation + "','" + location + "',  DateTime.Now  ,   DateTime.Now )", con);
            string connectionString = "Server=vishu;Database=LearningDB;Trusted_Connection=Yes";
            SqlConnection con = new SqlConnection(connectionString);
            string query = "insert into Employee values(@empName,@designation,@location,@createdDate,@modifiedDate)";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@empName", empName);
            cmd.Parameters.AddWithValue("@designation", designation);
            cmd.Parameters.AddWithValue("@location", location);
            cmd.Parameters.AddWithValue("@createdDate", DateTime.Now);
            cmd.Parameters.AddWithValue("@modifiedDate", DateTime.Now);
            cmd.CommandType = CommandType.Text;
            con.Open();
            count = cmd.ExecuteNonQuery();
            con.Close();
            return count;
        }

        internal DataSet GetEmployeeDetails()
        {
            string connectionString = "Server=vishu;Database=LearningDB;Trusted_Connection=Yes";
            using (SqlConnection sqlConnection = new SqlConnection(connectionString))
            {
                sqlConnection.Open();
                string query = "select * from Employee";
                SqlCommand cmd = new SqlCommand(query, sqlConnection);

                cmd.CommandType = CommandType.Text;
                using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                {
                    using (DataSet ds = new DataSet())
                    {
                        sda.Fill(ds);
                        sqlConnection.Close();
                        return ds;
                    }
                }
            }
        }
    }
}