﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using HelpText.DataAccessLayer;

namespace HelpText.BusinessLogicLayer
{
    public class EmployeeBAL
    {
        public int InsertEmployeeDetails(string empName, string designation, string location)
        {
            int count = 0;
            EmployeeDAL employeeDAL = new EmployeeDAL();
            count = employeeDAL.InsertEmployeeDetails(empName, designation, location);
            return count;
        }

        internal DataSet GetEmployeeDetails()
        {
            EmployeeDAL employeeDAL = new EmployeeDAL();
            DataSet dataSet = new DataSet();
            dataSet = employeeDAL.GetEmployeeDetails();
            return dataSet;
        }
    }
}